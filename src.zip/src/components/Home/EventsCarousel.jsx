"use client";

import { useEffect, useState, useRef, useCallback } from "react";
import Image from "next/image";
import { motion } from "framer-motion";
import { Calendar, MapPin, Ticket, ArrowRight, Users, CaretLeft, CaretRight } from "@phosphor-icons/react";

const API_BASE_URL = "https://api.ticketche.com/api/v2";

/* ─── helpers ─────────────────────────────────── */
const getEventImage = (e) =>
  e.images?.length > 0 ? e.images[0].url : "/images/logo.png";

const formatDate = (d) => {
  if (!d) return null;
  return new Date(d).toLocaleDateString("fr-FR", {
    day: "numeric", month: "short", year: "numeric",
  });
};

const getMinPrice = (tickets) => {
  const prices = (tickets ?? []).map((t) => t.price).filter((p) => p > 0);
  return prices.length === 0 ? "Gratuit" : Math.min(...prices).toLocaleString() + " FCFA";
};

/* ─── EventCard ────────────────────────────────── */
function EventCard({ event }) {
  const handleClick = () => {
    if (typeof window !== "undefined") {
      localStorage.setItem("selectedEvent", JSON.stringify(event));
      window.open(`/events/${event.id}`, "_blank");
    }
  };

  return (
    <motion.article
      onClick={handleClick}
      whileHover={{ y: -6, transition: { duration: 0.22, ease: "easeOut" } }}
      className="evc-card"
    >
      <div className="evc-card__img">
        <Image
          src={getEventImage(event)}
          alt={event.title}
          fill
          sizes="(max-width: 430px) 80vw, (max-width: 768px) 65vw, 380px"
          className="object-cover"
        />
        <div className="evc-card__img-gradient" />

        {event.is_featured && (
          <span className="evc-badge evc-badge--featured">✦ À la une</span>
        )}
        {event.category && (
          <span className="evc-badge evc-badge--cat">{event.category.title}</span>
        )}
      </div>

      <div className="evc-card__body">
        <h3 className="evc-card__title">{event.title}</h3>

        <div className="evc-card__meta">
          {event.start_date && (
            <span className="evc-card__meta-row">
              <Calendar className="evc-card__meta-icon" />
              {formatDate(event.start_date)}
            </span>
          )}
          {event.location_name && (
            <span className="evc-card__meta-row">
              <MapPin className="evc-card__meta-icon" />
              <span className="evc-card__meta-truncate">{event.location_name}</span>
            </span>
          )}
        </div>

        <div className="evc-card__footer">
          <span className="evc-card__price">
            <Ticket className="evc-card__price-icon" />
            {getMinPrice(event.tickets)}
          </span>
          <span className="evc-card__rsvp">
            <Users className="evc-card__rsvp-icon" />
            {event.reservations_count ?? 0}
          </span>
        </div>
      </div>
    </motion.article>
  );
}

/* ─── Carousel avec swipe corrigé ─── */
function Carousel({ events }) {
  const trackRef = useRef(null);
  const [canPrev, setCanPrev] = useState(false);
  const [canNext, setCanNext] = useState(true);
  const [activeIndex, setActiveIndex] = useState(0);
  const autoRef = useRef(null);
  const userInteracted = useRef(false);
  const isDragging = useRef(false);
  const startX = useRef(0);
  const scrollLeft = useRef(0);

  const getCardWidth = useCallback(() => {
    if (!trackRef.current) return 0;
    const slide = trackRef.current.querySelector('.evc-carousel__slide');
    return slide ? slide.offsetWidth + parseInt(getComputedStyle(trackRef.current).gap) : 0;
  }, []);

  const updateButtonsAndIndex = useCallback(() => {
    const el = trackRef.current;
    if (!el) return;
    
    setCanPrev(el.scrollLeft > 10);
    setCanNext(el.scrollLeft < el.scrollWidth - el.clientWidth - 10);
    
    const cardWidth = getCardWidth();
    if (cardWidth > 0) {
      const index = Math.round(el.scrollLeft / cardWidth);
      setActiveIndex(Math.min(index, events.length - 1));
    }
  }, [getCardWidth, events.length]);

  useEffect(() => {
    const el = trackRef.current;
    if (!el) return;
    
    el.addEventListener("scroll", updateButtonsAndIndex, { passive: true });
    updateButtonsAndIndex();
    
    return () => el.removeEventListener("scroll", updateButtonsAndIndex);
  }, [updateButtonsAndIndex, events]);

  // Auto-swipe
  const startAutoSwipe = useCallback(() => {
    clearInterval(autoRef.current);
    if (events.length <= 1) return;
    
    autoRef.current = setInterval(() => {
      if (userInteracted.current || isDragging.current) return;
      
      setActiveIndex((prev) => {
        const next = prev >= events.length - 1 ? 0 : prev + 1;
        if (trackRef.current) {
          const cardWidth = getCardWidth();
          trackRef.current.scrollTo({ 
            left: next * cardWidth, 
            behavior: "smooth" 
          });
        }
        return next;
      });
    }, 3000);
  }, [events.length, getCardWidth]);

  useEffect(() => {
    startAutoSwipe();
    return () => clearInterval(autoRef.current);
  }, [startAutoSwipe]);

  const pauseAndResume = useCallback(() => {
    userInteracted.current = true;
    clearInterval(autoRef.current);
    
    setTimeout(() => {
      userInteracted.current = false;
      startAutoSwipe();
    }, 6000);
  }, [startAutoSwipe]);

  const slideBy = (dir) => {
    const el = trackRef.current;
    if (!el) return;
    
    pauseAndResume();
    const amount = getCardWidth();
    el.scrollBy({ left: dir * amount, behavior: "smooth" });
  };

  const goToSlide = (index) => {
    if (!trackRef.current) return;
    pauseAndResume();
    const cardWidth = getCardWidth();
    trackRef.current.scrollTo({ left: index * cardWidth, behavior: "smooth" });
    setActiveIndex(index);
  };

  // Gestion du swipe (drag) - CORRIGÉ
  const onMouseDown = (e) => {
  e.preventDefault();
  isDragging.current = true;
  startX.current = e.pageX;
  scrollLeft.current = trackRef.current.scrollLeft;

  trackRef.current.style.cursor = "grabbing";
  trackRef.current.style.userSelect = "none";
  trackRef.current.style.scrollSnapType = "none";

  pauseAndResume();
};

const onMouseMove = (e) => {
  if (!isDragging.current) return;
  const walk = (startX.current - e.pageX) * 1.2; // sensibilité
  trackRef.current.scrollTo({ left: scrollLeft.current + walk, behavior: "auto" });
};

const onMouseUp = () => {
  if (!isDragging.current) return;

  isDragging.current = false;
  trackRef.current.style.cursor = "grab";
  trackRef.current.style.userSelect = "";
  trackRef.current.style.scrollSnapType = "x mandatory";

  // Snap à la slide la plus proche
  const cardWidth = getCardWidth();
  const newIndex = Math.round(trackRef.current.scrollLeft / cardWidth);
  trackRef.current.scrollTo({ left: newIndex * cardWidth, behavior: "smooth" });
  setActiveIndex(newIndex);

  setTimeout(() => startAutoSwipe(), 200);
};

const onMouseLeave = () => {
  if (isDragging.current) onMouseUp();
};

  // Gestion tactile
  const onTouchStart = (e) => {
    isDragging.current = true;
    startX.current = e.touches[0].pageX - trackRef.current.offsetLeft;
    scrollLeft.current = trackRef.current.scrollLeft;
    
    trackRef.current.style.scrollSnapType = "none";
    pauseAndResume();
  };

  const onTouchMove = (e) => {
    if (!isDragging.current) return;
    e.preventDefault();
    
    const x = e.touches[0].pageX - trackRef.current.offsetLeft;
    const walk = (x - startX.current) * 1.5;
    trackRef.current.scrollLeft = scrollLeft.current - walk;
  };

  const onTouchEnd = () => {
    if (!isDragging.current) return;
    
    isDragging.current = false;
    trackRef.current.style.scrollSnapType = "x mandatory";
    
    const cardWidth = getCardWidth();
    const newIndex = Math.round(trackRef.current.scrollLeft / cardWidth);
    trackRef.current.scrollTo({ left: newIndex * cardWidth, behavior: "smooth" });
    
    setTimeout(() => {
      startAutoSwipe();
    }, 200);
  };

  return (
    <div className="evc-carousel">
      <div
        ref={trackRef}
        className="evc-carousel__track"
        onMouseDown={onMouseDown}
        onMouseMove={onMouseMove}
        onMouseUp={onMouseUp}
        onMouseLeave={onMouseLeave}
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
      >
        {events.map((ev) => (
          <div key={ev.id} className="evc-carousel__slide">
            <EventCard event={ev} />
          </div>
        ))}
      </div>

      <button
        className={`evc-nav evc-nav--prev ${canPrev ? "evc-nav--active" : "evc-nav--disabled"}`}
        onClick={() => slideBy(-1)}
        disabled={!canPrev}
        aria-label="Précédent"
      >
        <CaretLeft className="evc-nav__icon" weight="bold" />
      </button>

      <button
        className={`evc-nav evc-nav--next ${canNext ? "evc-nav--active" : "evc-nav--disabled"}`}
        onClick={() => slideBy(1)}
        disabled={!canNext}
        aria-label="Suivant"
      >
        <CaretRight className="evc-nav__icon" weight="bold" />
      </button>

      {events.length > 1 && (
        <div className="evc-indicators">
          {events.map((_, index) => (
            <button
              key={index}
              className={`evc-indicator ${index === activeIndex ? 'evc-indicator--active' : ''}`}
              onClick={() => goToSlide(index)}
              aria-label={`Aller à la slide ${index + 1}`}
            />
          ))}
        </div>
      )}
    </div>
  );
}

/* ─── Section header aligné avec le carrousel ── */
function SectionHeader({ title, subtitle, viewAllLink = "/events" }) {
  return (
    <div className="evc-header">
      <div className="evc-header__text">
        <h2 className="evc-header__title">{title}</h2>
        <p className="evc-header__subtitle">{subtitle}</p>
      </div>
      <a href={viewAllLink} className="evc-header__cta">
        Tout voir
      </a>
    </div>
  );
}

/* ─── Skeleton ─────────────────────────────────── */
function SkeletonRow() {
  return (
    <div className="evc-carousel__track evc-carousel__track--nograb">
      {[...Array(4)].map((_, i) => (
        <div key={i} className="evc-carousel__slide" style={{ minWidth: '280px' }}>
          <div className="evc-skeleton" />
        </div>
      ))}
    </div>
  );
}

/* ─── MAIN ─────────────────────────────────────── */
export const EventsCarousel = () => {
  // ✅ Correction complète
const [featured, setFeatured] = useState([]);
const [loading, setLoading] = useState(true);

useEffect(() => {
  fetch(`${API_BASE_URL}/events`)
    .then((r) => r.json())
    .then(({ success, data }) => {
      if (!success) return;
      const all = data ?? [];

      const feat = all
        .filter((e) => e.is_featured)
        .sort((a, b) => (a.featured_order ?? 99) - (b.featured_order ?? 99));

      setFeatured(feat); // ✅ mise à jour du state
    })
    .catch((err) => console.error("Erreur fetch events:", err))
    .finally(() => setLoading(false)); // ✅ stoppe le loader dans tous les cas
}, []);

  return (
    <>
      <section id="events" className="evcSection">
        <div className="w-full mx-auto pt-10 sm:pt-12 pb-12 sm:pb-14">
          
          {/* CAROUSEL 1 : À la une */}
          <div className="mb-16">
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.6 }}
            >
              <SectionHeader 
                title="Événements à la une"
                subtitle="Les incontournables du moment, sélectionnés pour vous"
              />
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true, amount: 0.05 }}
              transition={{ duration: 0.7, delay: 0.15 }}
            >
              {loading ? <SkeletonRow /> : featured.length === 0
                ? <p className="evc-empty" style={{ paddingLeft: '5%' }}>Aucun événement à la une pour le moment.</p>
                : <Carousel events={featured} />
              }
            </motion.div>
          </div>

       

        </div>
      </section>
    </>
  );
};