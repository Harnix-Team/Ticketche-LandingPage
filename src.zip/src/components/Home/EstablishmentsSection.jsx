"use client";
import { useEffect, useState, useMemo } from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import { fetchAllPlaces } from "@/app/services/api";
import {
  NavigationArrow,
  MagnifyingGlass,
  X,
  Car,
  Drop,
  Wrench,
  SlidersHorizontal,
  ArrowRight,
  Sparkle,
} from "@phosphor-icons/react";
import { Calendar, MapPin, Ticket, Users } from "@phosphor-icons/react";

/* ─── helpers ─────────────────────────────────── */
const formatTicketcheImage = (img) =>
  img ? img.replace("/storage/app/public", "/storage") : "/images/logo.png";

const getPlaceImage = (place) =>
  place.images?.length > 0
    ? formatTicketcheImage(place.images[0].link)
    : "/images/Space/recom1.png";

const getServiceTags = (place) =>
  [...new Set(
    place.services
      .filter((s) => s.pivot.status === "ON")
      .map((s) => s.name),
  )].slice(0, 3);

const getMinimumPrice = (place) => {
  if (place.minimum_price) return `${place.minimum_price} FCFA`;
  const prices = place.services
    .filter((s) => s.pivot.status === "ON")
    .map((s) => s.pivot.price);
  return prices.length > 0 ? `${Math.min(...prices)} FCFA` : "Sur demande";
};

const getPlaceRating = (place) => {
  if (!place.noteUsers?.length) return null;
  const total = place.noteUsers.reduce((s, n) => s + parseFloat(n.star), 0);
  return (total / place.noteUsers.length).toFixed(1);
};

/* ─── PlaceCard — style EventCarousel ─────────── */
function PlaceCard({ place, onItinerary }) {
  const handleClick = () => {
    localStorage.setItem("selectedPlace", JSON.stringify(place));
    window.open(`/places/${place.id}`, "_blank");
  };

  return (
    <motion.article
      onClick={handleClick}
      whileHover={{ y: -6, transition: { duration: 0.22, ease: "easeOut" } }}
      className="est-card"
    >
      {/* Image */}
      <div className="est-card__img">
        <Image
          src={getPlaceImage(place)}
          alt={place.name}
          fill
          sizes="(max-width: 430px) 80vw, (max-width: 768px) 65vw, 380px"
          className="object-cover"
        />
        <div className="est-card__img-gradient" />

        {/* Badge note */}
        {getPlaceRating(place) && (
          <span className="est-badge est-badge--rating">
            ★ {getPlaceRating(place)}
          </span>
        )}

        {/* Badge ville */}
        {place.city && (
          <span className="est-badge est-badge--city">
            <MapPin weight="fill" style={{ width: 11, height: 11, display: "inline", marginRight: 3 }} />
            {place.city}
          </span>
        )}
      </div>

      {/* Body */}
      <div className="est-card__body">
        {/* Tags services */}
        <div className="est-card__tags">
          {getServiceTags(place).map((tag, i) => (
            <span key={i} className="est-card__tag">{tag}</span>
          ))}
        </div>

        <h3 className="est-card__title">{place.name}</h3>

        {/* Footer */}
        <div className="est-card__footer">
          <span className="est-card__price">
            <svg xmlns="http://www.w3.org/2000/svg" className="est-card__price-icon" viewBox="0 0 20 20" fill="currentColor">
              <path d="M8.433 7.418c.155-.103.346-.196.567-.267v1.698a2.305 2.305 0 01-.567-.267C8.07 8.34 8 8.114 8 8c0-.114.07-.34.433-.582zM11 12.849v-1.698c.22.071.412.164.567.267.364.243.433.468.433.582 0 .114-.07.34-.433.582a2.305 2.305 0 01-.567.267z"/>
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-13a1 1 0 10-2 0v.092a4.535 4.535 0 00-1.676.662C6.602 6.234 6 7.009 6 8c0 .99.602 1.765 1.324 2.246.48.32 1.054.545 1.676.662v1.941c-.391-.127-.68-.317-.843-.504a1 1 0 10-1.51 1.31c.562.649 1.413 1.076 2.353 1.253V15a1 1 0 102 0v-.092a4.535 4.535 0 001.676-.662C13.398 13.766 14 12.991 14 12c0-.99-.602-1.765-1.324-2.246A4.535 4.535 0 0011 9.092V7.151c.391.127.68.317.843.504a1 1 0 101.511-1.31c-.563-.649-1.413-1.076-2.354-1.253V5z" clipRule="evenodd"/>
            </svg>
            {getMinimumPrice(place)}
          </span>

          <button
            className="est-card__itinerary"
            onClick={(e) => { e.stopPropagation(); onItinerary(place.id); }}
          >
            <NavigationArrow style={{ width: 13, height: 13 }} />
            Itinéraire
          </button>
        </div>
      </div>
    </motion.article>
  );
}

/* ─── variants ─────────────────────────────────── */
const containerVariants = {
  hidden:  { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.08 } },
};
const itemVariants = {
  hidden:  { opacity: 0, y: 32 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.45, ease: [0.22, 1, 0.36, 1] } },
  exit:    { opacity: 0, y: -16, transition: { duration: 0.2 } },
};

/* ─── MAIN ─────────────────────────────────────── */
export const EstablishmentsSection = () => {
  const [establishments, setEstablishments] = useState([]);
  const [loading, setLoading]               = useState(true);
  const [searchQuery, setSearchQuery]       = useState("");
  const [activeFilter, setActiveFilter]     = useState("all");

  useEffect(() => {
    const loadPlaces = async () => {
      try {
        const response = await fetchAllPlaces();
        if (response.success) setEstablishments(response.data);
      } catch (_) {}
      finally { setLoading(false); }
    };
    loadPlaces();
  }, []);

  const handleItineraryClick = (placeId) => {
    window.open(`https://app.ticketche.com/places/itinerary?placeId=${placeId}`, "_blank");
  };

  const filteredEstablishments = useMemo(() => {
    let result = [...establishments];
    if (activeFilter !== "all")
      result = result.filter((p) =>
        p.services.some(
          (s) => s.pivot.status === "ON" &&
                 s.name.toLowerCase().includes(activeFilter.toLowerCase())
        )
      );
    if (searchQuery.trim())
      result = result.filter((p) => {
        const q = searchQuery.toLowerCase();
        return (
          p.name?.toLowerCase().includes(q) ||
          p.city?.toLowerCase().includes(q) ||
          p.services.some((s) => s.name.toLowerCase().includes(q))
        );
      });
    return result;
  }, [establishments, searchQuery, activeFilter]);

  // On limite à 4 établissements pour un layout 3 + 1 sur desktop
  const displayedEstablishments = filteredEstablishments.slice(-4).reverse();

  /* ── Loading ── */
  if (loading)
    return (
      <section className="pt-10 pb-20">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-3">
            {[0, 0.2, 0.4].map((delay, i) => (
              <motion.div
                key={i}
                className={`w-3 h-3 rounded-full ${i % 2 === 0 ? "bg-[#005f69]" : "bg-[#6a2d02]"}`}
                animate={{ scale: [1, 1.5, 1], opacity: [1, 0.4, 1] }}
                transition={{ duration: 1, repeat: Infinity, delay }}
              />
            ))}
          </div>
          <p className="text-gray-500 mt-4 text-sm font-medium">Chargement des établissements...</p>
        </div>
      </section>
    );

  if (!establishments.length) return null;

  return (
    <>
<section id="emplacements" className="estSection">
          <div className="estSection__inner">

          {/* ── Header ── */}
          {/* ── Header + CTA wrapper ── */}
<div className="est-header-row">

  <motion.div
    className="est-section-header"
    initial={{ opacity: 0, y: -24 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, amount: 0.3 }}
    transition={{ duration: 0.6, ease: "easeOut" }}
  >
    
    <h3 className="est-section-title">
      Établissements disponibles
    </h3>
    <p className="est-section-subtitle">
      Découvrez un réseau croissant de partenaires professionnels sélectionnés
      pour leur qualité de service et leur expertise.
    </p>
  </motion.div>

  <motion.div
    className="est-cta-top"
    initial={{ opacity: 0, x: 30 }}
    whileInView={{ opacity: 1, x: 0 }}
    viewport={{ once: true }}
    transition={{ delay: 0.3, duration: 0.5 }}
  >
    <motion.a
      href="/establishments"
      target="_blank"
      rel="noopener noreferrer"
      className="est-cta__btn"
      whileHover={{ scale: 1.04 }}
      whileTap={{ scale: 0.97 }}
    >
Tout voir      
    </motion.a>
  </motion.div>

</div>
          {/* ── Compteur résultats ── */}
          <AnimatePresence mode="wait">
            {(searchQuery || activeFilter !== "all") && (
              <motion.p
                key="result-count"
                className="est-result-count"
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
              >
                {displayedEstablishments.length === 0
                  ? "Aucun résultat trouvé"
                  : `${displayedEstablishments.length} établissement${displayedEstablishments.length > 1 ? "s" : ""} trouvé${displayedEstablishments.length > 1 ? "s" : ""}`}
              </motion.p>
            )}
          </AnimatePresence>

          {/* ── Grid ── */}
          <AnimatePresence mode="wait">
            {displayedEstablishments.length === 0 ? (
              <motion.div
                key="empty"
                className="est-empty"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
              >
                <div className="est-empty__icon">
                  <MagnifyingGlass style={{ width: 28, height: 28, color: "#d1d5db" }} />
                </div>
                <p className="est-empty__title">Aucun établissement trouvé</p>
                <p className="est-empty__sub">Essayez d'autres mots-clés ou retirez les filtres</p>
                <button
                  className="est-empty__reset"
                  onClick={() => { setSearchQuery(""); setActiveFilter("all"); }}
                >
                  Réinitialiser la recherche
                </button>
              </motion.div>
            ) : (
              <motion.div
                key={`grid-${activeFilter}-${searchQuery}`}
                className="est-grid"
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                {displayedEstablishments.map((place) => (
                  <motion.div key={place.id} variants={itemVariants} layout>
                    <PlaceCard
                      place={place}
                      onItinerary={handleItineraryClick}
                    />
                  </motion.div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>

      

        </div>
      </section>
    </>
  );
};

