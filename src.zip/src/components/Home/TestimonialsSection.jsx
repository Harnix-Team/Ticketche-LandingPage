"use client";
import Image from "next/image";
import { motion } from "framer-motion";
import { useEffect } from "react";

const testimonials = [
  { name: "Stéphane TOGBANOU", rating: 5, quote: "Depuis que j'utilise ticketché, la gestion de mes parkings est devenue un jeu d'enfant. L'application est intuitive et m'a fait gagner un temps précieux!", avatar: "/images/users/user1.png" },
  { name: "Fatoumata DIALLO", rating: 5, quote: "ticketché a complètement transformé ma façon de gérer mes véhicules professionnels. Gain de temps, traçabilité, simplicité - tout ce dont j'avais besoin !", avatar: "/images/users/user2.png" },
  { name: "Romuald SANNI", rating: 4, quote: "Je ne peux plus me passer de ticketché. Suivre mes entretiens, trouver un parking, programmer un lavage - tout est devenu tellement simple.", avatar: "/images/users/user3.png" },
  { name: "Patrick HOUNDJANTO", rating: 5, quote: "En tant que professionnelle mobile, ticketché est mon assistant indispensable. Je gère mes déplacements avec une efficacité incroyable.", avatar: "/images/users/user4.png" },
  { name: "Adjoua MENSAH", rating: 5, quote: "Une application vraiment bien pensée. Je recommande à tous les gérants de parking qui veulent moderniser leur activité.", avatar: "/images/users/user1.png" },
  { name: "Kofi AGBODOSSOU", rating: 4, quote: "Très pratique pour organiser mes événements. La vente de billets en ligne a boosté ma visibilité et mes ventes considérablement.", avatar: "/images/users/user2.png" },
  { name: "Bernadette DOSSOU",rating: 5, quote: "L'assistance 24h/24 est vraiment un plus. J'ai eu un problème un soir, résolu en moins de 10 minutes. Bravo à toute l'équipe !", avatar: "/images/users/user3.png" },
  { name: "Yao HOUETO",rating: 5, quote: "Le portefeuille électronique intégré simplifie tout. Plus besoin de jongler entre plusieurs applications pour gérer mes paiements.", avatar: "/images/users/user4.png" },
];

function StarRating({ rating }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((star) => (
        <svg key={star} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill={star <= rating ? "#F59E0B" : "none"} stroke={star <= rating ? "#F59E0B" : "#D1D5DB"} strokeWidth={1.5} className="w-3 h-3 sm:w-3.5 sm:h-3.5">
          <path strokeLinecap="round" strokeLinejoin="round" d="M11.48 3.499a.562.562 0 011.04 0l2.125 5.111a.563.563 0 00.475.345l5.518.442c.499.04.701.663.321.988l-4.204 3.602a.563.563 0 00-.182.557l1.285 5.385a.562.562 0 01-.84.61l-4.725-2.885a.563.563 0 00-.586 0L6.982 20.54a.562.562 0 01-.84-.61l1.285-5.386a.562.562 0 00-.182-.557l-4.204-3.602a.562.562 0 01.321-.988l5.518-.442a.563.563 0 00.475-.345L11.48 3.5z" />
        </svg>
      ))}
    </div>
  );
}

function TestimonialCard({ item }) {
  return (
    <div
      className="flex-shrink-0 bg-white border border-gray-100 rounded-2xl p-3 sm:p-4 shadow-sm flex flex-col gap-2 sm:gap-3"
      style={{ width: "clamp(240px, 80vw, 300px)", boxShadow: "0 2px 12px rgba(0,95,105,0.07)" }}
    >
      <div className="flex items-start gap-3 sm:gap-4">
        <div className="relative w-10 h-10 sm:w-12 sm:h-12 flex-shrink-0">
          <Image src={item.avatar} alt={item.name} layout="fill" objectFit="cover" className="rounded-full" />
        </div>
        <div className="min-w-0">
          <p className="font-bold text-gray-900 text-xs sm:text-sm leading-tight truncate">{item.name}</p>
          <p className="text-gray-400 text-[10px] sm:text-xs mb-0.5 sm:mb-1">{item.location}</p>
          <StarRating rating={item.rating} />
        </div>
      </div>
      <p className="text-gray-600 text-[10px] sm:text-xs leading-relaxed line-clamp-3">"{item.quote}"</p>
    </div>
  );
}

function InfiniteRow({ items, direction = "left", speed = 35 }) {
  const duplicated = [...items, ...items, ...items];
  const totalWidth = items.length * (300 + 16);

  useEffect(() => {
    const id = `scroll-style-${direction}`;
    if (document.getElementById(id)) return;
    const style = document.createElement("style");
    style.id = id;
    style.textContent = `
      @keyframes scroll-left-${totalWidth} {
        0%   { transform: translateX(0); }
        100% { transform: translateX(-${totalWidth + 16}px); }
      }
      @keyframes scroll-right-${totalWidth} {
        0%   { transform: translateX(-${totalWidth + 16}px); }
        100% { transform: translateX(0); }
      }
    `;
    document.head.appendChild(style);
  }, [direction, totalWidth]);

  return (
    <div className="overflow-hidden relative w-full">
      <div className="absolute left-0 top-0 bottom-0 z-10 pointer-events-none" style={{ width: "clamp(30px, 6vw, 80px)", background: "linear-gradient(to right, white, transparent)" }} />
      <div className="absolute right-0 top-0 bottom-0 z-10 pointer-events-none" style={{ width: "clamp(30px, 6vw, 80px)", background: "linear-gradient(to left, white, transparent)" }} />
      <div className="flex gap-3 sm:gap-4 w-max" style={{ animation: `scroll-${direction}-${totalWidth} ${speed}s linear infinite` }}>
        {duplicated.map((item, i) => <TestimonialCard key={i} item={item} />)}
      </div>
    </div>
  );
}

export const TestimonialsSection = () => {
  const row1 = testimonials.slice(0, 4);
  const row2 = testimonials.slice(4, 8);

  return (
<section
  id="reviews"
  className="pt-12 sm:pt-16 md:pt-24 pb-10 sm:pb-16 overflow-hidden"
  style={{
    background:
      "linear-gradient(145deg, #0f2e32 0%, #1f545a 45%, #438187 72%, #12393d 100%)",
  }}
>      

<div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          className="flex flex-col items-center text-center gap-2 sm:gap-3 mb-8 sm:mb-12"
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
<h2 className="title-sub text-white">            Ils parlent de leur expérience
          </h2>
<p className="text-base text-white/80 max-w-xs sm:max-w-md leading-snug">            Découvrez comment ticketché simplifie le quotidien de nos utilisateurs à travers leurs témoignages.
          </p>
        </motion.div>
      </div>

      <motion.div
        className="flex flex-col gap-3 sm:gap-4"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, delay: 0.2 }}
      >
        <InfiniteRow items={row1} direction="right" speed={30} />
        <InfiniteRow items={row2} direction="left" speed={25} />
      </motion.div>
    </section>
  );
};