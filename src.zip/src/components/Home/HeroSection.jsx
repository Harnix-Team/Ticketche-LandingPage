"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { AppDownloadButtons } from "../Appdownloadbuttons";
import { useEffect, useState } from "react";
import { Archivo } from "next/font/google";

const archivo = Archivo({ subsets: ["latin"], weight: ["400", "500", "600", "700", "900"] });

const WORDS = ["parkings", "garages", "lavages", "événements"];
const COLORS = ["#692C00", "#005F69", "#692C00", "#005F69"];

/* ─────────────────────────────────────────────
   Typewriter
───────────────────────────────────────────── */
function TypewriterWords() {
  const [idx, setIdx] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setIdx((prev) => (prev + 1) % WORDS.length);
    }, 2200);
    return () => clearInterval(interval);
  }, []);

  return (
    <motion.span
      key={idx}
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="inline-block"
      style={{ color: COLORS[idx] }}
    >
      {WORDS[idx]}
    </motion.span>
  );
}

/* ─────────────────────────────────────────────
   PhoneMockup
───────────────────────────────────────────── */
function PhoneMockup({ src, alt, appearDelay, rotation, floatOffset, floatDuration, floatDelay }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 80, scale: 0.82 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{
        delay: appearDelay,
        duration: 1,
        ease: [0.34, 1.4, 0.64, 1],
      }}
      style={{ rotate: `${rotation}deg` }}
    >
      <motion.div
        animate={{ y: [0, floatOffset, 0] }}
        transition={{
          delay: appearDelay + floatDelay,
          duration: floatDuration,
          repeat: Infinity,
          ease: "easeInOut",
          repeatType: "loop",
        }}
      >
        <div style={{ position: "relative", width: "900px", height: "2000px" }}>
          <Image
            src={src}
            alt={alt}
            fill
            sizes="450px"
            className="object-contain"
            priority
          />
        </div>
      </motion.div>
    </motion.div>
  );
}

const PHONES = [
  {
    src: "/images/Hero/accueil.png",
    alt: "Ticketché – Emplacements",
    appearDelay: 0.3,
    rotation: -12,
    floatOffset: -14,
    floatDuration: 3.8,
    floatDelay: 1.2,
  },
  {
    src: "/images/Hero/explorer.png",
    alt: "Ticketché – Événements",
    appearDelay: 0.6,
    rotation: 0,
    floatOffset: -18,
    floatDuration: 3.4,
    floatDelay: 1.0,
  },
  {
    src: "/images/Hero/recomm.png",
    alt: "Ticketché – Dashboard",
    appearDelay: 0.9,
    rotation: 25,
    floatOffset: -14,
    floatDuration: 4.0,
    floatDelay: 0.8,
  },
];

/* ─────────────────────────────────────────────
   HERO
───────────────────────────────────────────── */
export const Hero = () => {
  return (
    <section
      className={`${archivo.className} relative pb-10 lg:pb-0 pt-15 min-h-screen flex items-center overflow-hidden bg-gradient-to-b from-white via-[#E0F5F7]/40 to-white`}
    >
      {/* Background */}
      <motion.div className="absolute inset-0 z-0">
        <Image src="/images/Hero/bg.png" alt="Background" fill quality={90} priority />
      </motion.div>

      <motion.div className="relative z-20 w-full px-4 md:px-0">
        <div className="container mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">

            {/* ══════════ GAUCHE : texte ══════════ */}
            <motion.div
              initial={{ opacity: 0, x: -100 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, ease: "easeOut" }}
              className="text-center lg:text-left space-y-8 xl:pl-0"
            >
              <motion.h1
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3, duration: 0.8 }}
                className="title-hero"
              >
                <span>Retrouvez vos</span>
                <br />
                <span className="inline-block min-w-[160px]">
                  <TypewriterWords />
                </span>
                <br />
                <span className="text-gray-900">en un seul clic.</span>
              </motion.h1>

              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="text-lg md:text-xl text-gray-700 font-medium max-w-lg mx-auto lg:mx-0"
              >
                La solution digitale qui simplifie la supervision de vos
                parkings, garages, centres de lavage et événements au Bénin.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
              >
                <ul className="space-y-4 max-w-md w-full mx-auto lg:mx-0 text-left">
                  {[
                    "Gestion centralisée et fluide",
                    "Suivi en temps réel des tickets",
                    "Billetterie et contrôle d'accès pour vos événements",
                    "Transparence totale sur vos opérations",
                  ].map((service, index) => (
                    <motion.li
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.2, duration: 0.5 }}
                      className="flex items-start gap-3"
                    >
                      <span className="mt-1 text-white bg-amber-950 px-2 py-0.5 rounded-full text-xs">✓</span>
                      <span className="text-sm md:text-base">{service}</span>
                    </motion.li>
                  ))}
                </ul>
              </motion.div>

              {/* Boutons App Store / Google Play */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1 }}
                className="flex flex-wrap items-center justify-center lg:justify-start gap-4"
              >
                <AppDownloadButtons />
              </motion.div>

              {/* Social proof */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.2 }}
                className="flex items-center justify-center lg:justify-start gap-4 bg-white/70 backdrop-blur-md rounded-full px-6 py-3 shadow-lg border border-amber-100 w-fit mx-auto lg:mx-0"
              >
                <div className="flex -space-x-3">
                  {[1, 2, 3, 4].map((num) => (
                    <Image
                      key={num}
                      src={`/images/users/user${num}.png`}
                      alt={`User ${num}`}
                      width={45}
                      height={45}
                      className="rounded-full border-2 border-white shadow-md"
                    />
                  ))}
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">+30</p>
                  <p className="text-xs text-gray-600">Gérants actifs</p>
                </div>
              </motion.div>
            </motion.div>

            {/* ══════════ DROITE : téléphones ══════════ */}
            <div className="relative" style={{ overflow: "visible" }}>

              {/* ── MOBILE (< xl) : 2 vidéos ── */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8, rotateY: -30 }}
                animate={{ opacity: 1, scale: 1, rotateY: 0 }}
                transition={{ duration: 1, delay: 0.5 }}
                className="xl:hidden relative mx-auto w-full max-w-2xl flex gap-3 px-2"
              >
                <div className="flex-1 bg-white p-1.5 rounded-2xl shadow-2xl">
                  <div className="overflow-hidden rounded-xl">
                    <video autoPlay loop muted playsInline className="w-full h-auto object-cover">
                      <source src="/videos/hero.mp4" type="video/mp4" />
                    </video>
                  </div>
                </div>
                <div className="flex-1 bg-white p-1.5 rounded-2xl shadow-2xl">
                  <div className="overflow-hidden rounded-xl">
                    <video autoPlay loop muted playsInline className="w-full h-auto object-cover">
                      <source src="https://assets.mixkit.co/videos/17631/17631-720.mp4" type="video/mp4" />
                    </video>
                  </div>
                </div>
              </motion.div>

              {/* ── DESKTOP (xl+) : 3 téléphones sans cadre ── */}
              <div
                className="hidden xl:flex items-center justify-center"
                style={{ height: "900px", gap: "-5px" }} // plus proche
              >
                {/* GAUCHE — légèrement incliné et bas */}
                <div style={{ transform: "translateY(40px) translateX(800px)", zIndex: 1 }}>
                  <PhoneMockup {...PHONES[0]} />
                </div>

                {/* CENTRE — droit, surélevé et légèrement vers la gauche */}
                <div style={{ transform: "translateY(-20px) translateX(200px)", zIndex: 3 }}>
                  <PhoneMockup {...PHONES[1]} />
                </div>

                {/* DROITE — légèrement incliné et bas */}
                <div style={{ transform: "translateY(40px) translateX(-390px)", zIndex: 1 }}>
                  <PhoneMockup {...PHONES[2]} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </section>
  );
};