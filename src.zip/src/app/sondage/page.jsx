"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { useSearchParams } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import {
  ArrowRight, ArrowLeft, CheckCircle, ChartBar, Star,
  WhatsappLogo, MapPin, User, Car, Path, ArrowsClockwise,
  Warning, Sparkle, CreditCard, ChatText,
} from "@phosphor-icons/react";
import {
  fetchQuestionnaireBySlug,
  submitQuestionnaireAnswers,
} from "@/app/services/questionnairesApi";

const SURVEY_SLUG = "transport-covoiturage-2026";
const STORAGE_KEY = "ticketche_sondage_progress_v3";
const DONE_KEY    = "ticketche_sondage_done";

/* ── Icônes par section ───────────────────────────────────────────────────── */
const SECTION_ICONS = {
  s1: User,
  s2: Car,
  s3: Path,
  s4: ArrowsClockwise,
  s5: Warning,
  s6: Sparkle,
  s7: CreditCard,
  s8: ChatText,
};

/* ── Écrans ───────────────────────────────────────────────────────────────── */
const SCREENS = [
  { id:"s1", label:"Profil",      layout:"2x2",
    questions:["q1_age","q2_sexe","q3_profession","q4_vehicule"] },
  { id:"s2", label:"Conducteur",  layout:"2+3",
    questions:["q5_type_vehicule","q6_places","q7_carburant","q8_passagers","q8b_app"],
    showIf:{ questionId:"q4_vehicule", values:["oui"] } },
  { id:"s3", label:"Trajet",      layout:"1+2",
    questions:["q9_residence","q10_lieu_activite","q11_itineraire"] },
  { id:"s4", label:"Habitudes",   layout:"3x2",
    questions:["q12_frequence","q13_transport","q14_depart","q15_retour","q16_duree","q17_cout"] },
  { id:"s5", label:"Difficultés", layout:"1x2",
    questions:["q18_difficultes","q19_type_difficultes"] },
  { id:"s6", label:"TicketChé",   layout:"2x2",
    questions:["q20_interet","q21_service","q22_role","q23_reservation"] },
  { id:"s7", label:"Paiement",    layout:"3x2",
    questions:["q24_mobile_money","q25_smartphone","q26_paiement_app","q27_prix","q28_abonnement","q28b_prix_abo"] },
  { id:"s8", label:"Perception",  layout:"2+1",
    questions:["q29_avantages","q30_obstacles","q31_suggestions"] },
];

/* ── Conditions de visibilité ─────────────────────────────────────────────── */
const CONDS = {
  q5_type_vehicule:     { dep:"q4_vehicule",    vals:["oui"] },
  q6_places:            { dep:"q4_vehicule",    vals:["oui"] },
  q7_carburant:         { dep:"q4_vehicule",    vals:["oui"] },
  q8_passagers:         { dep:"q4_vehicule",    vals:["oui"] },
  q8b_app:              { dep:"q4_vehicule",    vals:["oui"] },
  q19_type_difficultes: { dep:"q18_difficultes",vals:["oui"] },
  q22_role:             { dep:"q21_service",    vals:["covoiturage","les_deux"] },
  q28b_prix_abo:        { dep:"q28_abonnement", vals:["oui","peut_etre"] },
};

function isVisible(qId, answers) {
  if (!CONDS[qId]) return true;
  const { dep, vals } = CONDS[qId];
  const given = answers[dep];
  const arr = Array.isArray(given) ? given : given ? [given] : [];
  return arr.some(v => vals.includes(v));
}

function getRequired(screen, answers, questionnaire) {
  if (!screen || !questionnaire) return [];
  return screen.questions.filter(qId => {
    if (!isVisible(qId, answers)) return false;
    const step = questionnaire.steps.find(s => s.id === qId);
    if (!step || step.optional) return false;
    if (screen.id === "s6" && answers.q20_interet === "non") return qId === "q20_interet";
    return true;
  });
}

/* ── UTM ──────────────────────────────────────────────────────────────────── */
function resolveSourceTag(s, m) {
  if (s==="terrain"&&m==="qrcode")  return "qrcode_terrain";
  if (s==="whatsapp"&&m==="social") return "whatsapp_uac";
  if (s==="gdiz"&&m==="interne")    return "gdiz_interne";
  if (s==="site"&&m==="bandeau")    return "bandeau_site";
  if (s==="site"&&m==="popup")      return "popup_site";
  return "organic";
}
function resolveLibreCanal(m) {
  if (m==="qrcode") return "libre_qrcode";
  if (m==="social") return "libre_whatsapp";
  return "libre_web";
}

/* ════════════════════════════════════════════════════════
   QuestionCard — cellule individuelle dans la grille
   ════════════════════════════════════════════════════════ */
function QuestionCard({ step, answers, onChange, spanClass, isMobile }) {
  if (!step) return null;
  const val = answers[step.id];
  const Icon = step.icon;
  /* Sur mobile : toujours en colonne pour respecter min 48px B4 */
  const isRow = !isMobile && step.options && step.options.length <= 3;

  const handleClick = (optId) => {
    if (step.type === "multi") {
      const cur = val || [];
      let next;
      if (cur.includes(optId)) next = cur.filter(v => v !== optId);
      else {
        if (step.maxSelect && cur.length >= step.maxSelect) return;
        next = [...cur, optId];
      }
      onChange(step.id, next);
    } else {
      onChange(step.id, optId);
    }
  };

  const isAnswered = Array.isArray(val) ? val.length > 0 : !!val;

  return (
    <div className={`snd-qcard ${isAnswered ? "snd-qcard--answered" : ""} ${spanClass || ""}`}>

      {/* En-tête question */}
      <div className="snd-qcard__head">
        {Icon && (
          <span className="snd-qcard__icon">
            <Icon size={15} weight="fill" />
          </span>
        )}
        <p className="snd-qcard__label">{step.question}</p>
        {step.type === "multi" && (
          <span className="snd-qcard__hint">
            {step.maxSelect ? `max ${step.maxSelect}` : "multi"}
          </span>
        )}
      </div>

      {/* Intro TicketChé */}
      {step.intro && (
        <div className="snd-qcard__intro">{step.intro}</div>
      )}

      {/* Corps */}
      <div className="snd-qcard__body">
        {step.type === "text" ? (
          <textarea
            className="snd-qcard__textarea"
            placeholder={step.placeholder || "Votre réponse…"}
            value={val || ""}
            onChange={e => onChange(step.id, e.target.value)}
            rows={3}
          />
        ) : (
          <div className={`snd-opts ${isRow ? "snd-opts--row" : ""}`}>
            {step.options?.map(opt => {
              const Ic = opt.icon;
              const selected = Array.isArray(val) ? val.includes(opt.id) : val === opt.id;
              return (
                <button
                  key={opt.id}
                  onClick={() => handleClick(opt.id)}
                  className={`snd-opt ${selected ? "snd-opt--on" : ""}`}
                >
                  {Ic && <Ic size={13} weight="fill" className="snd-opt__ic" />}
                  <span className="snd-opt__lbl">{opt.label}</span>
                  {selected && <CheckCircle size={12} weight="fill" className="snd-opt__chk" />}
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Champ "Pourquoi ?" conditionnel */}
      {step.endIfLabel && step.endIf?.values?.includes(val) && (
        <textarea
          className="snd-qcard__textarea snd-qcard__textarea--sm"
          placeholder="Pourquoi ? (optionnel)"
          value={answers[`${step.id}_reason`] || ""}
          onChange={e => onChange(`${step.id}_reason`, e.target.value)}
          rows={2}
        />
      )}
    </div>
  );
}

/* ════════════════════════════════════════════════════════
   ScreenGrid — grille adaptative par layout
   ════════════════════════════════════════════════════════ */
function ScreenGrid({ screen, visibleQIds, questionnaire, answers, onChange, isMobile }) {
  /* Sur mobile : toujours 1 colonne, quel que soit le layout */
  const gridClass = isMobile
    ? "snd-grid snd-grid--1col"
    : ({
        "2x2":  "snd-grid snd-grid--2x2",
        "3x2":  "snd-grid snd-grid--3x2",
        "1x2":  "snd-grid snd-grid--1col",
        "2+3":  "snd-grid snd-grid--6col",
        "2+1":  "snd-grid snd-grid--2col",
        "1+2":  "snd-grid snd-grid--2col",
      }[screen.layout] || "snd-grid snd-grid--1col");

  /* spanClass inutile sur mobile (grille 1col) */
  function spanClass(idx) {
    if (isMobile) return "";
    if (screen.layout === "2+3") return idx < 2 ? "snd-span3" : "snd-span2";
    if (screen.layout === "2+1") return idx >= 2 ? "snd-spanfull" : "";
    if (screen.layout === "1+2") return idx === 0 ? "snd-spanfull" : "";
    if (screen.layout === "1x2") return "snd-spanfull";
    return "";
  }

  return (
    <div className={gridClass}>
      {visibleQIds.map((qId, idx) => {
        const step = questionnaire.steps.find(s => s.id === qId);
        if (!step) return null;
        return (
          <QuestionCard
            key={qId}
            step={step}
            answers={answers}
            onChange={onChange}
            spanClass={spanClass(idx)}
            isMobile={isMobile}
          />
        );
      })}
    </div>
  );
}

/* ════════════════════════════════════════════════════════
   SuccessScreen
   ════════════════════════════════════════════════════════ */
function SuccessScreen() {
  const [rating, setRating] = useState(0);
  const shareText = encodeURIComponent(
    "TicketChé prépare un service de bus et de covoiturage sur Cotonou ↔ Abomey-Calavi. " +
    "Donnez votre avis en 3 min : https://ticketche.com/sondage"
  );
  return (
    <motion.div
      className="snd-success"
      initial={{ opacity:0, y:20 }}
      animate={{ opacity:1, y:0 }}
      transition={{ duration:0.45 }}
    >
      <div className="snd-success__ring">
        <CheckCircle size={44} weight="fill" />
      </div>
      <h2 className="snd-success__title">Merci ! Vos réponses ont été enregistrées.</h2>
      <p className="snd-success__sub">
        Partagez ce sondage à vos proches.
      </p>
      <a
        href={`https://wa.me/?text=${shareText}`}
        target="_blank"
        rel="noopener noreferrer"
        className="snd-wa-btn"
      >
        <WhatsappLogo size={20} weight="fill" />
        Partager sur WhatsApp
      </a>
      <p className="snd-success__stars-lbl">Comment évaluez-vous ce questionnaire ?</p>
      <div className="snd-success__stars">
        {[1,2,3,4,5].map(n => (
          <button key={n} className="snd-star-btn" onClick={() => setRating(n)}>
            <Star
              size={28}
              weight={n <= rating ? "fill" : "regular"}
              className={n <= rating ? "text-[#005f69]" : "text-[#c4d9db]"}
            />
          </button>
        ))}
      </div>
      {rating > 0 && <p className="snd-success__rated">Merci ✦</p>}
      <Link href="/questionnaires" className="snd-back-link">
        <ArrowLeft size={14} weight="bold" />
        Voir tous les questionnaires
      </Link>
    </motion.div>
  );
}

/* ════════════════════════════════════════════════════════
   PAGE PRINCIPALE
   ════════════════════════════════════════════════════════ */
export default function SondagePage() {
  const searchParams = useSearchParams();
  const utmSource   = searchParams.get("utm_source")   || "organic";
  const utmMedium   = searchParams.get("utm_medium")   || null;
  const utmCampaign = searchParams.get("utm_campaign") || null;
  const sourceTag   = resolveSourceTag(utmSource, utmMedium);
  const libreCanal  = resolveLibreCanal(utmMedium);

  const [questionnaire, setQuestionnaire]       = useState(null);
  const [loading, setLoading]                   = useState(true);
  const [currentScreenIdx, setCurrentScreenIdx] = useState(0);
  const [answers, setAnswers]                   = useState({});
  const [submitted, setSubmitted]               = useState(false);
  const [showForm, setShowForm]                 = useState(false);
  const [hasSavedProgress, setHasSavedProgress] = useState(false);
  const [commune, setCommune]                   = useState("");
  const [submitError, setSubmitError]           = useState(false);
  const [submitting, setSubmitting]             = useState(false);
  /* B4 — mobile wizard : une question à la fois */
  const [isMobile, setIsMobile]                 = useState(false);
  const [mobileSubIdx, setMobileSubIdx]         = useState(0);

  /* Ref sur la zone formulaire pour le scroll ciblé (évite de scroller le hero) */
  const formZoneRef = useRef(null);

  const scrollToForm = useCallback(() => {
    if (formZoneRef.current) {
      const headerH = document.querySelector(".hdrContainer")?.offsetHeight || 72;
      const top = formZoneRef.current.getBoundingClientRect().top + window.scrollY - headerH - 8;
      window.scrollTo({ top: Math.max(0, top), behavior: "smooth" });
    } else {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }, []);

  useEffect(() => {
    fetchQuestionnaireBySlug(SURVEY_SLUG)
      .then(setQuestionnaire)
      .finally(() => setLoading(false));
  }, []);

  /* Détection mobile — B4 */
  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 768);
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, []);

  /* Clamp mobileSubIdx si visibleQIds rétrécit suite à un changement de réponse */
  useEffect(() => {
    if (!isMobile) return;
    setMobileSubIdx(prev => {
      const max = Math.max(0, visibleQIds.length - 1);
      return prev > max ? max : prev;
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentScreenIdx, answers, isMobile]);

  useEffect(() => {
    if (!questionnaire) return;
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (!saved) return;
      const { answers: a, screenIdx, slug, commune: c, mobileSubIdx: msi } = JSON.parse(saved);
      if (slug !== SURVEY_SLUG) return;
      setAnswers(a || {});
      setCurrentScreenIdx(screenIdx || 0);
      if (msi) setMobileSubIdx(msi);
      if (c) setCommune(c);
      setHasSavedProgress(true);
    } catch (_) {}
  }, [questionnaire]);

  const saveProgress = useCallback((ans, idx, com, subIdx = 0) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({
        answers: ans, screenIdx: idx, slug: SURVEY_SLUG, commune: com, mobileSubIdx: subIdx,
      }));
    } catch (_) {}
  }, []);

  const clearProgress = useCallback(() => {
    try { localStorage.removeItem(STORAGE_KEY); } catch (_) {}
  }, []);

  /* Écrans actifs (filtrés par showIf) */
  const activeScreens = questionnaire
    ? SCREENS.filter(sc => {
        if (!sc.showIf) return true;
        const { questionId, values } = sc.showIf;
        const given = answers[questionId];
        const arr = Array.isArray(given) ? given : given ? [given] : [];
        return arr.some(v => values.includes(v));
      })
    : [];

  const currentScreen = activeScreens[currentScreenIdx];

  const visibleQIds = currentScreen && questionnaire
    ? currentScreen.questions.filter(qId => isVisible(qId, answers))
    : [];

  /* B4 — sur mobile : la question courante dans la section */
  const mobileVisibleQIds = isMobile ? [visibleQIds[mobileSubIdx]].filter(Boolean) : visibleQIds;
  const currentMobileQId  = isMobile ? visibleQIds[mobileSubIdx] : null;

  /* Calcul question globale pour le label "Question X sur N" — B4 */
  const totalVisibleQuestions = activeScreens.reduce((acc, sc) => {
    const visible = sc.questions.filter(qId => isVisible(qId, answers));
    return acc + visible.length;
  }, 0);
  const questionsBeforeScreen = activeScreens.slice(0, currentScreenIdx).reduce((acc, sc) => {
    return acc + sc.questions.filter(qId => isVisible(qId, answers)).length;
  }, 0);
  const currentQuestionNum = questionsBeforeScreen + (isMobile ? mobileSubIdx + 1 : visibleQIds.length ? 1 : 0);

  const canProceed = currentScreen && questionnaire
    ? (isMobile
        /* mobile : juste la question courante */
        ? (() => {
            const qId = visibleQIds[mobileSubIdx];
            if (!qId) return true;
            const step = questionnaire.steps.find(s => s.id === qId);
            if (!step || step.optional) return true;
            if (step.type === "text") return !!(answers[qId] || "").trim();
            if (step.type === "multi") return (answers[qId] || []).length > 0;
            return !!answers[qId];
          })()
        /* desktop : toutes les questions requises de la section */
        : getRequired(currentScreen, answers, questionnaire).every(qId => {
            const step = questionnaire.steps.find(s => s.id === qId);
            if (!step) return true;
            if (step.type === "text") return !!(answers[qId] || "").trim();
            if (step.type === "multi") return (answers[qId] || []).length > 0;
            return !!answers[qId];
          }))
    : false;

  const handleChange = useCallback((qId, value) => {
    setAnswers(prev => {
      const updated = { ...prev, [qId]: value };
      saveProgress(updated, currentScreenIdx, commune, mobileSubIdx);
      return updated;
    });
  }, [currentScreenIdx, commune, mobileSubIdx, saveProgress]);

  const handleNext = () => {
    /* ── Fix B6 : Q20 = "non" → soumettre immédiatement ── */
    if (answers.q20_interet === "non") {
      handleSubmit();
      return;
    }

    /* ── Fix B4 : mobile wizard — avancer question par question ── */
    if (isMobile && mobileSubIdx < visibleQIds.length - 1) {
      const next = mobileSubIdx + 1;
      setMobileSubIdx(next);
      scrollToForm();
      return;
    }

    /* ── Avancer à la section suivante (desktop ou fin de section mobile) ── */
    setMobileSubIdx(0);
    if (currentScreenIdx < activeScreens.length - 1) {
      const next = currentScreenIdx + 1;
      setCurrentScreenIdx(next);
      saveProgress(answers, next, commune, 0);
      scrollToForm();
    } else {
      handleSubmit();
    }
  };

  const handleBack = () => {
    /* ── Fix B4 : mobile wizard — reculer question par question ── */
    if (isMobile && mobileSubIdx > 0) {
      setMobileSubIdx(mobileSubIdx - 1);
      scrollToForm();
      return;
    }

    if (currentScreenIdx > 0) {
      const prev = currentScreenIdx - 1;
      /* sur mobile, aller à la dernière question de la section précédente */
      if (isMobile && questionnaire) {
        const prevScreen = activeScreens[prev];
        const prevVisible = prevScreen.questions.filter(qId => isVisible(qId, answers));
        setMobileSubIdx(Math.max(0, prevVisible.length - 1));
      } else {
        setMobileSubIdx(0);
      }
      setCurrentScreenIdx(prev);
      saveProgress(answers, prev, commune, isMobile ? Math.max(0, activeScreens[prev]?.questions.filter(q => isVisible(q, answers)).length - 1) : 0);
      scrollToForm();
    }
  };

  const handleSubmit = async () => {
    setSubmitError(false);
    setSubmitting(true);
    // answers = uniquement les réponses Q1-Q31
    const cleanAnswers = { ...answers };
    // metadata = champs doc B1 au même niveau que answers
    const metadata = {
      mode: "libre",
      mode_canal: libreCanal,
      utm_source: utmSource,
      utm_medium: utmMedium,
      utm_campaign: utmCampaign,
      source_tag: sourceTag,
      submitted_at: new Date().toISOString(),
      ...(commune.trim() ? { commune_declaree: commune.trim() } : {}),
    };
    try {
      await submitQuestionnaireAnswers(questionnaire.id, cleanAnswers, metadata);
      clearProgress();
      try { localStorage.setItem(DONE_KEY, "1"); } catch (_) {}
      setSubmitted(true);
      scrollToForm();
    } catch (err) {
      console.error("Erreur soumission sondage :", err);
      setSubmitError(true);
    } finally {
      setSubmitting(false);
    }
  };

  const shareText = encodeURIComponent(
    "TicketChé prépare un service de bus et de covoiturage sur Cotonou ↔ Abomey-Calavi. " +
    "Donnez votre avis en 3 min : https://ticketche.com/sondage"
  );

  /* ── Loading ── */
  if (loading) return (
    <div className="snd-loading">
      <div className="snd-loading__spinner" />
      <p>Chargement du sondage…</p>
    </div>
  );

  /* ── HERO — formulaire intégré directement, pas de redirection ── */
  const SectionIcon = currentScreen ? SECTION_ICONS[currentScreen.id] : null;

  return (
    <div className="snd-page">

      {/* ════════ HERO (toujours visible, formulaire en dessous) ════════ */}
      <section className="snd-hero">
        <div className="snd-hero__inner">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          >
            {/* Badge */}
            <div className="snd-hero__badge">
              <ChartBar size={12} weight="fill" />
              Sondage anonyme · 3 min
            </div>

            {/* Accroche */}
            <h1 className="snd-hero__title">
              Vos déplacements quotidiens méritent mieux.<br />
              Dites-nous comment.
            </h1>
            <p className="snd-hero__sub">
              TicketChé prépare un service de bus et de covoiturage sur
              Cotonou ↔ Abomey-Calavi. Votre avis compte — anonyme, gratuit.
            </p>

            {/* 3 chiffres clés */}
            <div className="snd-stats">
              <div className="snd-stat">
                <span className="snd-stat__val">51 000</span>
                <span className="snd-stat__lbl">étudiants concernés</span>
              </div>
              <div className="snd-stat">
                <span className="snd-stat__val">0</span>
                <span className="snd-stat__lbl">bus organisé aujourd&apos;hui</span>
              </div>
              <div className="snd-stat">
                <span className="snd-stat__val">Votre avis</span>
                <span className="snd-stat__lbl">change ça</span>
              </div>
            </div>

            {/* Commune (optionnel) */}
            {!showForm && !submitted && (
              <div className="snd-commune">
                <MapPin size={15} weight="fill" />
                <input
                  type="text"
                  placeholder="Votre commune (optionnel)"
                  value={commune}
                  onChange={e => setCommune(e.target.value)}
                  maxLength={80}
                  className="snd-commune__input"
                />
              </div>
            )}
          </motion.div>
        </div>
      </section>

      {/* ════════ FORMULAIRE INTÉGRÉ ════════ */}
      <div className="snd-form-zone" ref={formZoneRef}>

        {/* CTA initial */}
        {!showForm && !submitted && (
          <motion.div
            className="snd-cta-wrap"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.2 }}
          >
            <button className="snd-cta-btn" onClick={() => setShowForm(true)}>
              {hasSavedProgress ? "Reprendre le sondage" : "Participer au sondage"}
              <ArrowRight size={16} weight="bold" />
            </button>
            {hasSavedProgress && (
              <button
                className="snd-restart-btn"
                onClick={() => {
                  clearProgress();
                  setAnswers({});
                  setCurrentScreenIdx(0);
                  setHasSavedProgress(false);
                  setShowForm(true);
                }}
              >
                Recommencer depuis le début
              </button>
            )}
          </motion.div>
        )}

        {/* Succès */}
        {submitted && <SuccessScreen />}

        {/* Formulaire actif */}
        {showForm && !submitted && currentScreen && questionnaire && (
          <>
            {/* Barre de progression */}
            <div className="snd-progress">
              <div className="snd-progress__track">
                {activeScreens.map((sc, i) => (
                  <div
                    key={sc.id}
                    className={`snd-progress__seg ${
                      i < currentScreenIdx ? "snd-progress__seg--done"
                      : i === currentScreenIdx ? "snd-progress__seg--active"
                      : ""
                    }`}
                  />
                ))}
              </div>
              {/* B4 — "Question X sur N" */}
              <span className="snd-progress__lbl">
                {isMobile
                  ? `Question ${currentQuestionNum} sur ${totalVisibleQuestions}`
                  : `Section ${currentScreenIdx + 1} / ${activeScreens.length}`}
              </span>
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={isMobile ? `${currentScreen.id}-${mobileSubIdx}` : currentScreen.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
              >
                {/* En-tête section */}
                <div className="snd-section-head">
                  {SectionIcon && <SectionIcon size={16} weight="fill" className="snd-section-head__icon" />}
                  <span className="snd-section-head__lbl">{currentScreen.label}</span>
                  <div className="snd-section-head__line" />
                </div>

                {/* Grille de cards */}
                <ScreenGrid
                  screen={currentScreen}
                  visibleQIds={isMobile ? mobileVisibleQIds : visibleQIds}
                  questionnaire={questionnaire}
                  answers={answers}
                  onChange={handleChange}
                  isMobile={isMobile}
                />

                {/* Navigation */}
                <div className="snd-nav">
                  <div>
                    {(currentScreenIdx > 0 || (isMobile && mobileSubIdx > 0)) && (
                      <button className="snd-nav__back" onClick={handleBack}>
                        <ArrowLeft size={14} weight="bold" />
                        Précédent
                      </button>
                    )}
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 8 }}>
                    {submitError && (
                      <p style={{ fontSize: 12, color: "#dc2626", margin: 0 }}>
                        Une erreur est survenue. Vérifiez votre connexion et réessayez.
                      </p>
                    )}
                    <button
                      className="snd-nav__next"
                      onClick={handleNext}
                      disabled={!canProceed || submitting}
                    >
                      {submitting
                        ? "Envoi en cours…"
                        : answers.q20_interet === "non"
                          ? "Terminer le sondage"
                          : (isMobile
                              ? (mobileSubIdx < visibleQIds.length - 1
                                  ? "Question suivante"
                                  : currentScreenIdx === activeScreens.length - 1
                                    ? "Envoyer mes réponses"
                                    : "Section suivante")
                              : currentScreenIdx === activeScreens.length - 1
                                ? "Envoyer mes réponses"
                                : "Section suivante")}
                      {!submitting && <ArrowRight size={15} weight="bold" />}
                    </button>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </>
        )}

        {/* Bouton WhatsApp en bas de page */}
        <div className="snd-wa-footer">
          <a
            href={`https://wa.me/?text=${shareText}`}
            target="_blank"
            rel="noopener noreferrer"
            className="snd-wa-btn"
          >
            <WhatsappLogo size={20} weight="fill" />
            Partagez ce sondage à vos proches
          </a>
        </div>
      </div>
    </div>
  );
}